﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamTest2
{
    public class OrderContains
    {
        public ObservableCollection<Product> ListProduct;
        public OrderContains()
        {
            ListProduct = new ObservableCollection<Product>();
        }
    }
}
