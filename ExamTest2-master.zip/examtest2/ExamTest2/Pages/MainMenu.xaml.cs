﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace ExamTest2.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainMenu.xaml
    /// </summary>
    public partial class MainMenu : Page
    {
        user15Entities context = new user15Entities();
        OrderContains OrderList;
        public MainMenu()
        {
            InitializeComponent();
            context = new user15Entities();
            DTGridMainMenu.ItemsSource = context.Product.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
          
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            //Product CurrentProduct = DTGridMainMenu.SelectedItem as Product;
            //if (CurrentProduct == null)
            //    MessageBox.Show("Выберите продукт!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            //else
            //{
            //    Product FindProduct = OrderList.ListProduct.FirstOrDefault(x => x.ID == CurrentProduct.ID);
            //    if (FindProduct == null)
            //    {
            //        CurrentProduct.ProductSum = 1;
            //        OrderList.ListProduct.Add(CurrentProduct);
            //    }else
            //    {
            //        foreach (var item in OrderList.ListProduct)
            //        {
            //            if (item.ID == FindProduct.ID)
            //                item.ProductSum++;
            //        }                
            //    }
            //    OrderBtn.Visibility = Visibility.Visible;
            //}

        }

        private void SearchProduct_SelectionChanged(object sender, RoutedEventArgs e)
        {
            List<Product> ProductListSearch = context.Product.Where (x => x.NameProduct.ToLower().Contains(SearchProduct.Text.ToLower())).ToList();
            if (ProductListSearch.Count == 0 && SearchProduct.Text != "") 
            {
                MessageBox.Show("Поиск не дал результатов", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }else
            {
                DTGridMainMenu.ItemsSource = ProductListSearch;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DTGridMainMenu.ItemsSource = context.Product.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            OrderWindow orderWindow = new OrderWindow(context, OrderList);
            orderWindow.ShowDialog();

        }
    }
}
